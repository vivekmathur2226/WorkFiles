﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
namespace JQueryDemo.Examples
{
    public partial class Example6 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.AppSettings["ConstrRetailApp"]);
            conn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            System.Text.StringBuilder objStr=new System.Text.StringBuilder();
            objStr.Append("SELECT PTD.PaymentID,RD.RegistrationNo,RTM.RegistrationType,UM.FirstName,UM.LastName,UM.EmailID,PTD.TransactionID,PTD.UpdatedOn AS PAIDON,");
			objStr.Append(" PTD.Status,PMM.PaymentMode,PTD.BANKNAME,PTD.PAYMENTDATE,PTD.AMOUNT,PTD.BANKACCOUNTNO,PTD.BANKACCOUNTTYPE,PTD.BANKBRANCHADDRESS");
			objStr.Append(" FROM OFFLINE_PAYMENTDETAILS PTD INNER JOIN RegistrationDetails RD ON PTD.PaymentID=RD.PAYMENTID AND PTD.Userid=RD.UserID INNER JOIN RegistrationTypeMaster RTM");
            objStr.Append(" ON RTM.TypeID=RD.RegistrationTypeID INNER JOIN UserMaster UM ON UM.UserID=PTD.Userid INNER JOIN paymentModeMaster PMM  ON PMM.PaymentTypeID=PTD.PAYMENTMODEID");
            cmd.CommandText = objStr.ToString();
            SqlDataAdapter da = new SqlDataAdapter(objStr.ToString(), conn);
            System.Data.DataSet ds = new System.Data.DataSet();
            da.Fill(ds);
            grdVwPaymentDetailsReport.DataSource = ds;
            grdVwPaymentDetailsReport.DataBind();

        }
    }
}