﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace JsonExample
{
    public partial class Default : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            if(!Page.IsPostBack)
            {
                Employee.list.Clear();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns>static list</returns>
        [WebMethod]
        public static List<Employee> GetAllEmployees()
        {
            if(Employee.list.Count() <= 0)
            {
                Employee.list.Add(new Employee { n_Id = 1, s_Name = "Amin", d_Salary = 25000 });
                Employee.list.Add(new Employee { n_Id = 2, s_Name = "Harshad", d_Salary = 24000 });
                Employee.list.Add(new Employee { n_Id = 3, s_Name = "Chetan", d_Salary = 23500 });
                Employee.list.Add(new Employee { n_Id = 4, s_Name = "Santosh", d_Salary = 23000 });
                Employee.list.Add(new Employee { n_Id = 5, s_Name = "Aniruddha", d_Salary = 23000 });
            }

            return Employee.list;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="employeeId"></param>
        /// <returns></returns>
        [WebMethod]
        public static Employee GetEmployeeDetails(string employeeId)
        {
            int empId = Int32.Parse(employeeId);
            Employee emp = Employee.list.Single(e => e.n_Id == empId);
            return emp;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="employeeId"></param>
        /// <returns></returns>
        [WebMethod]
        public static string AddEmployeeDetails(string s_Name, string d_Salary)
        {
            var EmployeeIDs = Employee.list.Select(r => r.n_Id);

            Employee.list.Add(new Employee { n_Id = (EmployeeIDs.Max() + 1), s_Name = s_Name, d_Salary = Convert.ToInt32(d_Salary) });

            return "Record added successfully...";
        }
    }
}