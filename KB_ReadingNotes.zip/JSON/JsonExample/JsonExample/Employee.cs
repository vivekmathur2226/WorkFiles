﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Employee
/// </summary>
public class Employee
{
    public int n_Id { get; set; }
    public string s_Name { get; set; }
    public decimal d_Salary { get; set; }

    public static List<Employee> list = new List<Employee>();
}
