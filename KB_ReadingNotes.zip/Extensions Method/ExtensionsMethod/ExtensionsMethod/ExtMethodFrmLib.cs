﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ExtensionMethodLib;

namespace ExtensionsMethod
{
    public static class ExtMethodFrmLib
    {
        public static void NewMethod(this ExtensionMethodLib.ExtMethod ext)
        {
            Console.WriteLine("Hello I m extended method");
        }
    }
}
