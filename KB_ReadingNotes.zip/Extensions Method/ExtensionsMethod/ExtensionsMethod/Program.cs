﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ExtensionMethodLib;

namespace ExtensionsMethod
{
    class Program
    {
        static void Main(string[] args)
        {
            string strInput = "Raju,Ram,Manish";
            string strReplace = ",";
            int posQuote = 0;
            int j = 0;
            ArrayList arrForReplacedString = new ArrayList();
            while ((posQuote = strInput.IndexOf(strReplace, posQuote)) != -1)
            {
                arrForReplacedString.Insert(j, posQuote.ToString());
                j++;
                posQuote++;
            }
            if (arrForReplacedString.Count > 0)
            {
                for (int pos = 1; pos <= arrForReplacedString.Count; pos++)
                {
                    if (pos.Equals(arrForReplacedString.Count))
                    {
                        strInput = strInput.ReplaceAt(Convert.ToInt32(arrForReplacedString[pos - 1]), '&');
                        strInput = strInput.Replace("&", " & ");
                    }
                }
            }
            Console.WriteLine(strInput);

            ExtMethod ob = new ExtMethod();
            Console.WriteLine(ob.Display());
            Console.WriteLine(ob.Print());
            ob.NewMethod();

            Console.ReadKey();


        }
    }
}
