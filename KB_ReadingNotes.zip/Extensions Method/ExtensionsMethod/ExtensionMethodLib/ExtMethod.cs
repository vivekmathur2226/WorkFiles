﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExtensionMethodLib
{
    public class ExtMethod
    {
        public string Display()
        {
            return ("Display Method");
        }

        public string Print()
        {
            return ("Print Method");
        }
    }
}
