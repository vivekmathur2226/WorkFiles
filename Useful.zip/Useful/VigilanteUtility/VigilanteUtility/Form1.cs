﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VigilanteUtility
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void EncryptButton_Click(object sender, EventArgs e)
        {
            string inputValue = richTextBox1.Text;
            string encryptedResult = string.Empty;
            if (inputValue != "" || inputValue != string.Empty)
            {
                DataSecurity objDataSecurity = new DataSecurity();
                objDataSecurity.SymmetricEncryption(inputValue, out encryptedResult);
                richTextBox2.Text = encryptedResult;
            }
        }

        private void DecryptButton_Click(object sender, EventArgs e)
        {
            string inputValue = richTextBox1.Text;
            string decryptedResult = string.Empty;
            if (inputValue != "" || inputValue != string.Empty)
            {
                DataSecurity objDataSecurity = new DataSecurity();
                objDataSecurity.SymmetricDecryption(inputValue, out decryptedResult);
                richTextBox2.Text = decryptedResult;
            }
        }
    }
}
