﻿using System;

public class DataUtility
{
    public DataUtility()
	{
	}

    #region Encrypt Data
    /// <summary>
    /// This method is used for encrypting the data using the encryption mentioned in the Web.config file
    /// </summary>
    /// <param name="i_sString"></param>
    /// <param name="o_sEncryptedString"></param>
    /// <returns></returns>
    public static bool encryptData(string i_sString, out string o_sEncryptedString)
    {
        bool bReturn = false;
        o_sEncryptedString = "";
        string sEncryptionKey = "Ps46klO0argt3mqY7FuwHt9zHQjv64LX";
        try
        {
            InsiderTradingEncryption.DataSecurity objDataSecurity = new InsiderTradingEncryption.DataSecurity();

            if (sEncryptionKey == null)
            {
                objDataSecurity.SymmetricEncryption(i_sString, out o_sEncryptedString);
            }
            else
            {
                objDataSecurity.SymmetricEncryption(i_sString, sEncryptionKey, out o_sEncryptedString);
            }


            bReturn = true;
        }
        catch (Exception exp)
        {
            bReturn = false;
        }
        return bReturn;
    }
    #endregion Encrypt Data

    #region Dencrypt Data
    /// <summary>
    /// This method is used for encrypting the data using the encryption mentioned in the Web.config file
    /// </summary>
    /// <param name="i_sEncryptedString"></param>
    /// <param name="o_sDencryptedString"></param>
    /// <returns></returns>
    public static bool dencryptData(string i_sEncryptedString, out string o_sDencryptedString)
    {
        bool bReturn = false;
        o_sDencryptedString = "";
        string sEncryptionKey = "Ps46klO0argt3mqY7FuwHt9zHQjv64LX";
        try
        {
            InsiderTradingEncryption.DataSecurity objDataSecurity = new InsiderTradingEncryption.DataSecurity();

            sEncryptionKey = System.Configuration.ConfigurationManager.AppSettings["EncryptionString"];
            if (sEncryptionKey == null)
            {
                objDataSecurity.SymmetricDecryption(i_sEncryptedString, out o_sDencryptedString);
            }
            else
            {
                objDataSecurity.SymmetricDecryption(i_sEncryptedString, sEncryptionKey, out o_sDencryptedString);
            }

            bReturn = true;
        }
        catch (Exception exp)
        {
            bReturn = false;
        }
        return bReturn;
    }
    #endregion Dencrypt Data
}
