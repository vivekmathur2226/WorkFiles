﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Password
{
    static class Program
    {

        private static Dictionary<String, int> processData(
                                        IEnumerable<string> lines)
        {
            /*
             * Do not make any changes outside this method.
             *
             * Modify this method to process `array` as indicated
             * in the question. At the end, return the size of the
             * array.
             *
             * Do not print anything in this method
             *
             * Submit this entire program (not just this function)
             * as your answer
             */

            Dictionary<string, int> tempDictionary = new Dictionary<string, int>();
            lines = File.ReadAllLines(@"D:\input.txt");
           
            foreach (var line in lines)
            {
                string trimmed = line.Trim();
                int firstindex = trimmed.IndexOf('|');
                int endIndex = trimmed.LastIndexOf('|');
                string subjectName = line.Substring(firstindex, endIndex - firstindex).Trim();
                endIndex = trimmed.LastIndexOf('|');
                string scoreString = line.Substring(endIndex, line.Count() - endIndex).Trim();
                int score = -1;
                if (!Int32.TryParse(scoreString, out score))
                    continue;
                if (tempDictionary.ContainsKey(subjectName))
                {
                    //var v = new var();
                    //if (!tempDictionary.TryGetValue(subjectName, out v))
                    //    continue;
                    //v.value += score;
                    //v.count++;
                    //tempDictionary[subjectName] = v;
                }
                else
                {
                    //tempDictionary.Add(subjectName, new var() { count = 1, value = score });
                }
            }
            //return the smallest ID record
            return tempDictionary;
            //return tempDictionary.Where(e => e.Value == tempDictionary.Min(e2 => e2.Value)).First();
        }
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Password());
            //Test
            try
            {
                Dictionary<String, int> retVal = processData(
                    File.ReadAllLines(@"D:\input.txt"));
                File.WriteAllLines("output.txt",
                    retVal.Select(x => x.Key + ": " + x.Value).ToArray());
            }
            catch (IOException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
