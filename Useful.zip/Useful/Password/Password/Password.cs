﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Security.Cryptography;
using System.Net;
using System.Net.Security;
using System.Net.Http.Headers;
using System.Net.Http.Formatting;
using System.Xml;
using System.Xml.Linq;
using System.Net.Http;
using System.Web.Http;
namespace Password
{
    public partial class Password : Form
    {
        public Password()
        {
            InitializeComponent();

        }
        string strReturnData = string.Empty;

        private XElement ConvertObjectToXMLString(object classObject)
        {
            XElement xElement = null;
            try
            {
                System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(classObject.GetType());
                XmlWriterSettings settings = new XmlWriterSettings();
                settings.Encoding = new System.Text.UnicodeEncoding(false, false); // no BOM in a .NET string
                settings.Indent = true;
                settings.OmitXmlDeclaration = true;
                string temp;
                using (System.IO.StringWriter textWriter = new System.IO.StringWriter())
                {
                    using (XmlWriter xmlWriter = XmlWriter.Create(textWriter, settings))
                    {
                        serializer.Serialize(xmlWriter, classObject);
                    }
                    temp = textWriter.ToString();
                    xElement = XElement.Parse(temp);
                }
            }
            catch
            {
                // Logged Exception

            }
            return xElement;
        }

        private void btnEncrypt_Click(object sender, EventArgs e)
        {
            try
            {
                if ((txtValue.Text != string.Empty) || (txtValue.Text.Length > 0) || (txtValue.Text != ""))
                {
                    txtResult.Text = CommonClass.EncryptString(txtValue.Text);

                    label3.Text = "STATUS:- Encrypted Success";
                }
                else
                {
                    label3.Text = "STATUS:- Please insert text in value box";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                label3.Text = "ERROR occurred during ENCRYPTING";
            }
        }
        private void btnDecrypt_Click(object sender, EventArgs e)
        {
            try
            {
                if ((txtValue.Text != string.Empty) || (txtValue.Text.Length > 0) || (txtValue.Text != ""))
                {
                    txtResult.Text = CommonClass.DecryptString(txtValue.Text);
                    label3.Text = "STATUS:- Decrypted Success";
                }
                else
                {
                    label3.Text = "STATUS:- Please insert text in value box";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                label3.Text = "ERROR occurred during DECRYPTING";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            #region Commented
            ////Creating Request XML data
            //StringBuilder strRBLRequest = new StringBuilder();
            //strRBLRequest.Append("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>");
            ////strRBLRequest.Append("<>");
            //strRBLRequest.Append(" <RetrieveTransactionStatusRequest xmlns=\"https://onlinedev.rblbank.com/corp/XService\"");
            //strRBLRequest.Append(" xmlns:hd=\"https://onlinedev.rblbank.com/corp/header\"");
            //strRBLRequest.Append(" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"");
            //strRBLRequest.Append(" xsi:schemaLocation=\"https://onlinedev.rblbank.com/corp/XService RetrieveTransactionStatusRequest.xsd\">");

            ////strRBLRequest.Append(" <RetrieveTransactionStatusRequest xmlns=\"http://www.infosys.com/request/RetrieveTransactionStatus\"");
            ////strRBLRequest.Append(" xmlns:hd=\"http://www.infosys.com/request/header\"");
            ////strRBLRequest.Append(" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"");
            ////strRBLRequest.Append(" xsi:schemaLocation=\"http://www.infosys.com/request/RetrieveTransactionStatus RetrieveTransactionStatusRequest.xsd\">");

            //strRBLRequest.Append("<hd:header>");
            //strRBLRequest.Append("<hd:BANK_ID>176</hd:BANK_ID>");
            //strRBLRequest.Append("<hd:LANGUAGE_ID>001</hd:LANGUAGE_ID>");
            //strRBLRequest.Append("<hd:CHANNEL_ID>I</hd:CHANNEL_ID>");
            //strRBLRequest.Append("<hd:LOGIN_FLAG>2</hd:LOGIN_FLAG>");
            //strRBLRequest.Append("<hd:__SRVCID__>RRTSE</hd:__SRVCID__>");
            //strRBLRequest.Append("<hd:STATEMODE>N</hd:STATEMODE>");
            //strRBLRequest.Append("<hd:OPFMT>XML</hd:OPFMT>");
            //strRBLRequest.Append("<hd:IPFMT>XML</hd:IPFMT>");
            //strRBLRequest.Append("<hd:ISMULTIREC>N</hd:ISMULTIREC>");
            //strRBLRequest.Append("<hd:USER_PRINCIPAL>176.ESOPADM1</hd:USER_PRINCIPAL>");
            //strRBLRequest.Append("<hd:CORP_PRINCIPAL></hd:CORP_PRINCIPAL>");
            //strRBLRequest.Append("<hd:ACCESS_CODE>d#demo1234</hd:ACCESS_CODE>");
            //strRBLRequest.Append("<hd:FORM_ID></hd:FORM_ID>");
            //strRBLRequest.Append("<hd:LOGIN_TYPE></hd:LOGIN_TYPE>");
            //strRBLRequest.Append("<hd:RELATIONSHIP_ID></hd:RELATIONSHIP_ID>");
            //strRBLRequest.Append("<hd:IP_ADDRESS></hd:IP_ADDRESS>");
            //strRBLRequest.Append("<hd:PORTAL_REQUEST></hd:PORTAL_REQUEST>");
            //strRBLRequest.Append("<hd:PORTAL_RANDOM_ID></hd:PORTAL_RANDOM_ID>");
            //strRBLRequest.Append("<hd:USER_ID></hd:USER_ID>");
            //strRBLRequest.Append("<hd:ISATTACHMENT></hd:ISATTACHMENT>");
            //strRBLRequest.Append("<hd:DEVICE_ID></hd:DEVICE_ID>");
            //strRBLRequest.Append("<hd:DEVICE_TYPE></hd:DEVICE_TYPE>");
            //strRBLRequest.Append("<hd:MACHINE_FINGER_PRINT></hd:MACHINE_FINGER_PRINT>");
            //strRBLRequest.Append("<hd:BROWSER_TYPE></hd:BROWSER_TYPE>");
            //strRBLRequest.Append("<hd:REQUESTED_FRAME_START_INDEX></hd:REQUESTED_FRAME_START_INDEX>");
            //strRBLRequest.Append("</hd:header>");

            //strRBLRequest.Append("<RetrieveTransactionStatus>");
            //strRBLRequest.Append("<BNF_ID>281207</BNF_ID>");
            //strRBLRequest.Append("<REFERENCE_ID>1939249</REFERENCE_ID>");
            //strRBLRequest.Append("<TOTAL_AMOUNT>2</TOTAL_AMOUNT>");
            ////Reference Id passed and transaction date needs to valid to get the response as observed via SAOP UI
            //strRBLRequest.Append("<TRANSACTION_DATE>05/06/2017</TRANSACTION_DATE>"); //DateTime.Now.ToString("dd/MM/yyyy").ToUpper()
            //strRBLRequest.Append("<TRANSACTION_CURRENCY>INR</TRANSACTION_CURRENCY>");
            //strRBLRequest.Append("<DESTINATION_ENTITY_TYPE>M</DESTINATION_ENTITY_TYPE>");
            //strRBLRequest.Append("<CP_REMARKS></CP_REMARKS>");
            //strRBLRequest.Append("</RetrieveTransactionStatus>");
            //strRBLRequest.Append("</RetrieveTransactionStatusRequest>");
            #endregion

            //XNamespace ns = "http://www.infosys.com/request/RetrieveTransactionStatus";
            //XNamespace schemaLocation = XNamespace.Get("http://www.infosys.com/request/RetrieveTransactionStatus RetrieveTransactionStatusRequest.xsd");
            //XNamespace xsi = XNamespace.Get("http://www.w3.org/2001/XMLSchema-instance");

            //XDocument doc = new XDocument(
            //    new XElement(ns + "RetrieveTransactionStatusRequest",
            //                 new XAttribute("xmlns", ns.NamespaceName),
            //                 new XAttribute(XNamespace.Xmlns + "hd",
            //                      "http://www.infosys.com/request/header"),
            //                 new XAttribute(XNamespace.Xmlns + "xsi",
            //                      "http://www.w3.org/2001/XMLSchema-instance"),
            //                 new XAttribute(xsi + "schemaLocation", schemaLocation)
            //                )
                         
            //                );    
          
            

            ///DEV URL Verification request
            XmlWriterSettings xsw = new XmlWriterSettings();
            StringBuilder sw = new StringBuilder();
            //string test = string.Empty;
            using (XmlWriter xw = XmlWriter.Create(sw, xsw))
            {
                xw.WriteStartElement("RetrieveTransactionStatusRequest", "xmlns=\"https://onlineuat.rblbank.com/corp/XService\"" +
                "xmlns:hd=\"https://onlineuat.rblbank.com/corp/header\"" +
                "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"" +
                "xsi:schemaLocation=\"https://onlineuat.rblbank.com/corp/XService RetrieveTransactionStatusRequest.xsd\"");

                //strRBLRequest.Append(" <RetrieveTransactionStatusRequest xmlns=\"https://onlinedev.rblbank.com/corp/XService\"");
                //strRBLRequest.Append(" xmlns:hd=\"https://onlinedev.rblbank.com/corp/header\"");
                //strRBLRequest.Append(" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"");
                //strRBLRequest.Append(" xsi:schemaLocation=\"https://onlinedev.rblbank.com/corp/XService RetrieveTransactionStatusRequest.xsd\">");

                xw.WriteStartElement("hd", "header", "urn:samples");

                xw.WriteAttributeString("xmlns", "hd", null, "urn:samples");
                string prefix = xw.LookupPrefix("urn:samples");
                xw.WriteStartElement(prefix, "BANK_ID", "urn:samples");
                xw.WriteString("176");
                xw.WriteEndElement();

                xw.WriteElementString("LANGUAGE_ID", "urn:samples", "001");
                xw.WriteElementString("CHANNEL_ID", "urn:samples", "I");
                xw.WriteElementString("LOGIN_FLAG", "urn:samples", "2");
                xw.WriteElementString("__SRVCID__", "urn:samples", "RRTSE");
                xw.WriteElementString("STATEMODE", "urn:samples", "N");

                xw.WriteElementString("OPFMT", "urn:samples", "XML");
                xw.WriteElementString("IPFMT", "urn:samples", "XML");
                xw.WriteElementString("ISMULTIREC", "urn:samples", "N");
                xw.WriteElementString("USER_PRINCIPAL", "urn:samples", "176.ESOPADM1");//DEV: 176.VSWAP
                xw.WriteElementString("CORP_PRINCIPAL", "urn:samples", "");


                xw.WriteElementString("ACCESS_CODE", "urn:samples", "d#demo1234");//Dev:d#demo
                xw.WriteElementString("FORM_ID", "urn:samples", "");
                xw.WriteElementString("LOGIN_TYPE", "urn:samples", "");
                xw.WriteElementString("RELATIONSHIP_ID", "urn:samples", "");
                xw.WriteElementString("IP_ADDRESS", "urn:samples", "");

                xw.WriteElementString("PORTAL_REQUEST", "urn:samples", "");
                xw.WriteElementString("PORTAL_RANDOM_ID", "urn:samples", "");
                xw.WriteElementString("LOGIN_TYPE", "urn:samples", "");
                xw.WriteElementString("USER_ID", "urn:samples", "");
                xw.WriteElementString("ISATTACHMENT", "urn:samples", "");

                xw.WriteElementString("DEVICE_ID", "urn:samples", "");
                xw.WriteElementString("DEVICE_TYPE", "urn:samples", "");
                xw.WriteElementString("MACHINE_FINGER_PRINT", "urn:samples", "");
                xw.WriteElementString("BROWSER_TYPE", "urn:samples", "");
                xw.WriteElementString("REQUESTED_FRAME_START_INDEX", "urn:samples", "");

                xw.WriteEndElement();

                xw.WriteStartElement("RetrieveTransactionStatus");

                xw.WriteElementString("BNF_ID", "281207"); //DEV 309016
                xw.WriteElementString("REFERENCE_ID", "1972928"); //"1910732" 1967470
                xw.WriteElementString("TOTAL_AMOUNT", "1");//2
                ///Reference Id passed and transaction date needs to valid to get the response as observed via SAOP UI
                xw.WriteElementString("TRANSACTION_DATE", "25/10/2017"); //DateTime.Now.ToString("dd/MM/yyyy").ToUpper() 24/04/2017
                xw.WriteElementString("TRANSACTION_CURRENCY", "INR");
                xw.WriteElementString("DESTINATION_ENTITY_TYPE", "M");
                xw.WriteElementString("CP_REMARKS", "");

                xw.WriteEndElement(); //"/RetrieveTransactionStatus"

                xw.WriteEndElement(); //"RetrieveTransactionStatusRequest";
                //xw.Settings.Encoding.HeaderName("IPTYPE", "XML");
                //test = xw.ToString();
            }

            #region UAT verification XML details
            //XmlWriterSettings xsw = new XmlWriterSettings();
            //StringBuilder sw = new StringBuilder();
            //string test = string.Empty;
            //using (XmlWriter xw = XmlWriter.Create(sw, xsw))
            //{
            //    xw.WriteStartElement("RetrieveTransactionStatusRequest", "xmlns=\"http://www.infosys.com/request/RetrieveTransactionStatus\"" +
            //    "xmlns:hd=\"http://www.infosys.com/request/header\"" +
            //    "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"" +
            //    "xsi:schemaLocation=\"http://www.infosys.com/request/RetrieveTransactionStatus RetrieveTransactionStatusRequest.xsd\"");

            //    xw.WriteStartElement("hd", "header", "urn:samples");

            //    // Write the namespace declaration.
            //    xw.WriteAttributeString("xmlns", "hd", null, "urn:samples");
            //    // Lookup the prefix and write the ISBN element.
            //    string prefix = xw.LookupPrefix("urn:samples");
            //    xw.WriteStartElement(prefix, "BANK_ID", "urn:samples");
            //    xw.WriteString("176");
            //    xw.WriteEndElement();

            //    // Write the style element (shows a different way to handle prefixes).
            //    xw.WriteElementString("LANGUAGE_ID", "urn:samples", "001");
            //    xw.WriteElementString("CHANNEL_ID", "urn:samples", "I");
            //    xw.WriteElementString("LOGIN_FLAG", "urn:samples", "2");
            //    xw.WriteElementString("__SRVCID__", "urn:samples", "RRTSE");
            //    xw.WriteElementString("STATEMODE", "urn:samples", "N");

            //    xw.WriteElementString("OPFMT", "urn:samples", "XML");
            //    xw.WriteElementString("IPFMT", "urn:samples", "XML");
            //    xw.WriteElementString("ISMULTIREC", "urn:samples", "N");
            //    xw.WriteElementString("USER_PRINCIPAL", "urn:samples", "176.ESOPADM1");
            //    xw.WriteElementString("CORP_PRINCIPAL", "urn:samples", "");


            //    xw.WriteElementString("ACCESS_CODE", "urn:samples", "d#demo1234");
            //    xw.WriteElementString("FORM_ID", "urn:samples", "");
            //    xw.WriteElementString("LOGIN_TYPE", "urn:samples", "");
            //    xw.WriteElementString("RELATIONSHIP_ID", "urn:samples", "");
            //    xw.WriteElementString("IP_ADDRESS", "urn:samples", "");

            //    xw.WriteElementString("PORTAL_REQUEST", "urn:samples", "");//Esop@1234
            //    xw.WriteElementString("PORTAL_RANDOM_ID", "urn:samples", "");
            //    xw.WriteElementString("LOGIN_TYPE", "urn:samples", "");
            //    xw.WriteElementString("USER_ID", "urn:samples", "");
            //    xw.WriteElementString("ISATTACHMENT", "urn:samples", "");

            //    xw.WriteElementString("DEVICE_ID", "urn:samples", "");
            //    xw.WriteElementString("DEVICE_TYPE", "urn:samples", "");
            //    xw.WriteElementString("MACHINE_FINGER_PRINT", "urn:samples", "");
            //    xw.WriteElementString("BROWSER_TYPE", "urn:samples", "");
            //    xw.WriteElementString("REQUESTED_FRAME_START_INDEX", "urn:samples", "");

            //    xw.WriteEndElement();//"hd:header"

            //    xw.WriteStartElement("RetrieveTransactionStatus");

            //    xw.WriteElementString("BNF_ID", "281207");
            //    xw.WriteElementString("REFERENCE_ID", "1910733");
            //    xw.WriteElementString("TOTAL_AMOUNT", "2");
            //    ///Reference Id passed and transaction date needs to valid to get the response as observed via SAOP UI
            //    xw.WriteElementString("TRANSACTION_DATE", "24/04/2017"); //DateTime.Now.ToString("dd/MM/yyyy").ToUpper()
            //    xw.WriteElementString("TRANSACTION_CURRENCY", "INR");
            //    xw.WriteElementString("DESTINATION_ENTITY_TYPE", "M");
            //    xw.WriteElementString("CP_REMARKS", "");

            //    xw.WriteEndElement(); //"/RetrieveTransactionStatus"

            //    xw.WriteEndElement(); //"RetrieveTransactionStatusRequest";
            //    //xw.Settings.Encoding.HeaderName("IPTYPE", "XML");
            //    test = xw.ToString();
            //}
            #endregion
            ///
            string str_PaymentDetails = "";
            //str_PaymentDetails = "Action: PG Dual Verification Initiated |";
            var temp = sw.ToString();
            str_PaymentDetails = temp; //str_PaymentDetails + temp; strRBLRequest.ToString();  
            //Task<string> strRetData = HttpClientCall(str_PaymentDetails);
            //MessageBox.Show(strRetData.Result.ToString());
            string strRetData = HttpClientCall(str_PaymentDetails);
            MessageBox.Show(strRetData);


            //string strReturnData = string.Empty;
            //Create a HttpClient
            //using (System.Net.Http.HttpClient client = new System.Net.Http.HttpClient())
            //{
            //    //Create a webrequest
            //    //WebRequest request = WebRequest.Create("https://onlineuat.rblbank.com/corp/XService");
            //    HttpRequestMessage requestMessage = new HttpRequestMessage(HttpMethod.Post, "https://onlineuat.rblbank.com/corp/XService");
            //    requestMessage.Headers.Clear();
            //    requestMessage.Headers.TryAddWithoutValidation("Content-Type", "application/xml");
            //    requestMessage.Headers.TryAddWithoutValidation("IPTYPE", "XML");
            //    requestMessage.Content = new StringContent(strRBLRequest.ToString(), Encoding.UTF8, "application/xml");
            //    requestMessage.Content.Headers.TryAddWithoutValidation("IPTYPE", "XML");
            //    //    requestMessage.Method = "Post";
            //    //    postData = "XMLData=" + xd;
            //    //    byte[] byteArray = Encoding.UTF8.GetBytes(xd.InnerXml.ToString());                
            //    //    var httpContent = new StringContent(xd.InnerXml.ToString(), Encoding.UTF8, "application/xml");
            //    //     // Send the request to the server
            //    HttpResponseMessage response = client.PostAsync("https://onlineuat.rblbank.com/corp/XService", requestMessage.Content).Result;
            //    //HttpResponseMessage response = await httpClient.PostAsync(requestMessage.RequestUri, requestMessage.Content).ConfigureAwait(false);
            //    strReturnData =  response.Content.ReadAsStringAsync().ConfigureAwait(false).ToString();
            //    response.EnsureSuccessStatusCode();
            //    MessageBox.Show(strReturnData);
            //}        

        }

        private string HttpClientCall(string strContent)
        {
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create("https://onlineuat.rblbank.com/corp/XService");
                byte[] bytes;
                //string requestXML = "<?xml version='1.0' encoding='utf-8'?><RetrieveTransactionStatusRequest xmlns='xmlns=&quot;http://www.infosys.com/request/RetrieveTransactionStatus&quot;xmlns:hd=&quot;http://www.infosys.com/request/header&quot;xmlns:xsi=&quot;http://www.w3.org/2001/XMLSchema-instance&quot;xsi:schemaLocation=&quot;http://www.infosys.com/request/RetrieveTransactionStatus RetrieveTransactionStatusRequest.xsd&quot;'><hd:header><hd:BANK_ID>176</hd:BANK_ID><hd:LANGUAGE_ID>001</hd:LANGUAGE_ID><hd:CHANNEL_ID>I</hd:CHANNEL_ID><hd:LOGIN_FLAG>2</hd:LOGIN_FLAG><hd:__SRVCID__>RRTSE</hd:__SRVCID__><hd:STATEMODE>N</hd:STATEMODE><hd:OPFMT>XML</hd:OPFMT><hd:IPFMT>XML</hd:IPFMT><hd:ISMULTIREC>N</hd:ISMULTIREC><hd:USER_PRINCIPAL>176.VSWAP</hd:USER_PRINCIPAL><hd:CORP_PRINCIPAL /><hd:ACCESS_CODE>d#demo</hd:ACCESS_CODE><hd:FORM_ID /><hd:LOGIN_TYPE /><hd:RELATIONSHIP_ID /><hd:IP_ADDRESS /><hd:PORTAL_REQUEST>Esop@1234</hd:PORTAL_REQUEST><hd:PORTAL_RANDOM_ID /><hd:LOGIN_TYPE /><hd:USER_ID /><hd:ISATTACHMENT /><hd:DEVICE_ID /><hd:DEVICE_TYPE /><hd:MACHINE_FINGER_PRINT /><hd:BROWSER_TYPE /><hd:REQUESTED_FRAME_START_INDEX /></hd:header><RetrieveTransactionStatus><BNF_ID>309016</BNF_ID><REFERENCE_ID>3314597</REFERENCE_ID><TOTAL_AMOUNT>2</TOTAL_AMOUNT><TRANSACTION_DATE>07/09/2017</TRANSACTION_DATE><TRANSACTION_CURRENCY>INR</TRANSACTION_CURRENCY><DESTINATION_ENTITY_TYPE>M</DESTINATION_ENTITY_TYPE><CP_REMARKS /></RetrieveTransactionStatus></RetrieveTransactionStatusRequest>";
                string requestXML = strContent;
                bytes = System.Text.Encoding.ASCII.GetBytes(requestXML);
                request.ContentType = "text/xml;charset='UTF-16'";
                request.ContentLength = bytes.Length;
                request.Headers.Set("IPTYPE", "XML");
                //request.Headers.Set("Keep-Alive", "timeout=600");
                request.UserAgent = "Apache-HttpClient/4.1.1 (java 1.5)";

                request.Method = "POST";
                Stream requestStream = request.GetRequestStream();
                requestStream.Write(bytes, 0, bytes.Length);

                requestStream.Close();
                HttpWebResponse response;
                response = (HttpWebResponse)request.GetResponse();

                MessageBox.Show("response.StatusCode+ " + response.StatusCode);
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    Stream responseStream = response.GetResponseStream();
                    string responseStr = new StreamReader(responseStream).ReadToEnd();
                    txtResult.Text = responseStr;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception-" + ex.Message.ToString());
            }
            return txtResult.Text;
        }
        //private async Task<string> HttpClientCall_OLD(HttpContent strContent)
        //{
        //    try
        //    {
        //        // Create a client
        //        HttpClient httpClient = new HttpClient();
        //        // Add a new Request Message
        //        HttpRequestMessage requestMessage = new HttpRequestMessage(HttpMethod.Post, "https://onlinedev.rblbank.com/corp/XService");
        //        // Add our custom headers
        //        requestMessage.Headers.Clear();
        //        requestMessage.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/xml"));
        //        requestMessage.Headers.TryAddWithoutValidation("IPTYPE", "XML");
        //        //requestMessage.Headers.Add("Content-Type", "application/xml");
        //        requestMessage.Headers.Add("IPTYPE", "XML");
        //        requestMessage.Content = strContent;
        //        //requestMessage.Content.Headers.TryAddWithoutValidation("IPTYPE", "XML");

        //        //bytes = System.Text.Encoding.ASCII.GetBytes(xd.InnerXml);
        //        //requestMessage.Content = new ByteArrayContent(bytes);
        //        httpClient.DefaultRequestHeaders.Accept.Clear();
        //        httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/xml"));
        //        httpClient.DefaultRequestHeaders.Add("IPTYPE", "XML");

        //        // Send the request to the server
        //        //HttpResponseMessage response = await httpClient.SendAsync(requestMessage,HttpCompletionOption.ResponseHeadersRead);
        //        HttpResponseMessage response = await httpClient.PostAsync(requestMessage.RequestUri, requestMessage.Content).ConfigureAwait(false);
        //        //strReturnData = await response.Content.ReadAsStringAsync();
        //        //response.EnsureSuccessStatusCode();
        //        return await response.Content.ReadAsStringAsync();

        //    }
        //    catch (HttpRequestException ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //        return null;
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //        return null;
        //    }

        //}

        private async Task<string> HttpClientCall_Last(string strContent)
        {
            try
            {
                // Create a client
                HttpClient httpClient = new HttpClient();
                // Add a new Request Message
                
                HttpRequestMessage requestMessage = new HttpRequestMessage(HttpMethod.Post, "https://onlinedev.rblbank.com/corp/XService");
                //// Add our custom headers
                //requestMessage.Headers.Clear();
                //httpClient.DefaultRequestHeaders.Accept.Clear();
                httpClient.DefaultRequestHeaders.Add("Connection", "Keep-Alive");
                httpClient.DefaultRequestHeaders.Add("Keep-Alive", "timeout=false");
                httpClient.DefaultRequestHeaders.Add("UserAgent", "Apache-HttpClient/4.1.1 (java 1.5)");
                httpClient.DefaultRequestHeaders.Add("content-type", "Application/XML");
                httpClient.DefaultRequestHeaders.Add("IPTYPE", "XML");
                
                //httpClient.Headers.Add("content-type", "text/html");
                //requestMessage.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("IPTYPE"));
                //requestMessage.Headers.TryAddWithoutValidation("IPTYPE", "XML");
                //requestMessage.Headers.Add("Content-Type", "application/xml");
                //string bytes[] = System.Text.Encoding.ASCII.GetBytes(strContent);
                //requestMessage.ContentType = "text/xml;charset='UTF-8'";
                requestMessage.Content = new StringContent(strContent);
                
                // Send the request to the server
                //HttpResponseMessage response = await httpClient.SendAsync(requestMessage,HttpCompletionOption.ResponseHeadersRead);
                HttpResponseMessage response = await httpClient.PostAsync(requestMessage.RequestUri, requestMessage.Content).ConfigureAwait(false);
                //strReturnData = await response.Content.ReadAsStringAsync();
                //response.EnsureSuccessStatusCode();
                return await response.Content.ReadAsStringAsync();

            }
            catch (HttpRequestException ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //SortedDictionary<string, int> tempDictionary = new SortedDictionary<string, int>();
            ////lines = inputstring.Split('\n');
            //int employeeID;
            //int lastempId = 0;
            //string[] lines = File.ReadAllLines(@"D:\input.txt");
            //foreach (var line in lines)
            //{
            //    string trimmed = line.Trim();
            //    int firstindex = trimmed.IndexOf('|') + 1;
            //    int endIndex = trimmed.LastIndexOf('|');
            //    int i;
            //    bool bret = Int32.TryParse(line.Substring(0, firstindex -1), out employeeID);
            //    string subjectName = line.Substring(firstindex, endIndex - firstindex).Trim();
            //    endIndex = trimmed.LastIndexOf('|') + 1;
            //    string scoreString = line.Substring(endIndex, line.Count() - endIndex).Trim();
            //    int score = -1;
            //    if (!Int32.TryParse(scoreString, out score))
            //        continue;
            //    tempDictionary.Add(subjectName, score);                
            //}
            //return the smallest ID record
            //return tempDictionary.First().Value;
            //return tempDictionary.Where(e => e.Value == tempDictionary.Min(e2 => e2.Value)).First();
        }
    }
}

