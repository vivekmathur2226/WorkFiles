﻿using System;

namespace Password
{
    class CommonClass
    {
        //this method is passing parameter to cryptography class to encrypt data 
        public static string EncryptString(string strQueryString)
        {
            try
            {
                SymCryptography symCryptography = new SymCryptography(SymCryptography.ServiceProviderEnum.AesManaged);
                symCryptography.Key = "29304E8758327892";
                return symCryptography.Encrypt(strQueryString, true);
            }
            catch (Exception ex)
            {
                throw new System.Exception(ex.ToString());
            }
        }
        //this method is passing parameter to cryptography class to decrypt data 
        public static string DecryptString(string strQueryString)
        {
            try
            {
                SymCryptography symCryptography = new SymCryptography("aesmanaged");
                symCryptography.Key = "29304E8758327892";
                return symCryptography.Decrypt(strQueryString, true);
            }
            catch (Exception ex)
            {
                throw new System.Exception(ex.ToString());
            }
        }      


    }
}
