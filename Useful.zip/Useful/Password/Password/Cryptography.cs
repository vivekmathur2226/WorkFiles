﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace Password
{
    #region SYMMETRIC CRYPTOGRAPHY CLASS

    public class SymCryptography : IDisposable
    {
        #region Private members...

        private string mKey = string.Empty;
        private string mSalt = string.Empty;
        private ServiceProviderEnum mAlgorithm;
        private SymmetricAlgorithm mCryptoService;

        private void SetLegalIV()
        {
            // Set symmetric algorithm
            switch (mAlgorithm)
            {
                case ServiceProviderEnum.AesCryptoServiceProvider:
                    mCryptoService.IV = new byte[] { 0xa, 0xd1, 0xee, 0xd, 0xc1, 0xaa, 0xe, 0xb, 0xdd, 0xcc, 0xa1, 0xc, 0xbb, 0xf, 0xb1, 0xff };
                    break;
            }
        }

        #endregion

        #region Public interfaces...

        public enum ServiceProviderEnum : int
        {
            AesCryptoServiceProvider,
            AesManaged
        }

        public SymCryptography()
        {
            // Default symmetric algorithm
            mCryptoService = new RijndaelManaged();
            mCryptoService.Mode = CipherMode.CBC;
            mAlgorithm = ServiceProviderEnum.AesCryptoServiceProvider;
        }

        public SymCryptography(ServiceProviderEnum serviceProvider)
        {
            // Select symmetric algorithm
            switch (serviceProvider)
            {
                case ServiceProviderEnum.AesCryptoServiceProvider:
                    mCryptoService = new AesCryptoServiceProvider();
                    mCryptoService.BlockSize = 128;
                    mCryptoService.KeySize = 256;
                    mCryptoService.Mode = CipherMode.CBC;
                    mCryptoService.Padding = PaddingMode.PKCS7;
                    mAlgorithm = ServiceProviderEnum.AesCryptoServiceProvider;
                    break;

                case ServiceProviderEnum.AesManaged:
                    mCryptoService = new AesManaged();
                    mCryptoService.BlockSize = 128;
                    mCryptoService.KeySize = 256;
                    mCryptoService.Mode = CipherMode.ECB;
                    mCryptoService.Padding = PaddingMode.PKCS7;
                    mAlgorithm = ServiceProviderEnum.AesManaged;
                    break;

            }            
        }

        public SymCryptography(string serviceProviderName)
        {
            try
            {
                // Select symmetric algorithm
                switch (serviceProviderName.ToLower())
                {
                    case "aescryptoserviceprovider":
                        serviceProviderName = "AesCryptoServiceProvider";
                        mAlgorithm = ServiceProviderEnum.AesCryptoServiceProvider;
                        break;
                    case "aesmanaged":
                        serviceProviderName = "AesManaged";
                        mAlgorithm = ServiceProviderEnum.AesManaged;
                        break;
                }

                mCryptoService = (SymmetricAlgorithm)CryptoConfig.CreateFromName(serviceProviderName);                
            }
            catch
            {
                throw;
            }
        }

        public virtual byte[] GetLegalKey(bool IsWithUTF8)
        {
            if (!IsWithUTF8)
            {
                // Adjust key if necessary, and return a valid key
                if (mCryptoService.LegalKeySizes.Length > 0)
                {
                    // Key sizes in bits
                    int keySize = mKey.Length * 8;
                    int minSize = mCryptoService.LegalKeySizes[0].MinSize;
                    int maxSize = mCryptoService.LegalKeySizes[0].MaxSize;
                    int skipSize = mCryptoService.LegalKeySizes[0].SkipSize;

                    if (keySize > maxSize)
                    {
                        // Extract maximum size allowed
                        mKey = mKey.Substring(0, maxSize / 8);
                    }
                    else if (keySize < maxSize)
                    {
                        // Set valid size
                        int validSize = (keySize <= minSize) ? minSize : (keySize - keySize % skipSize) + skipSize;
                        if (keySize < validSize)
                        {
                            // Pad the key with asterisk to make up the size
                            mKey = mKey.PadRight(validSize / 8, '*');
                        }
                    }
                }
                PasswordDeriveBytes key = new PasswordDeriveBytes(mKey, ASCIIEncoding.ASCII.GetBytes(mSalt));
                return key.GetBytes(mKey.Length);
            }
            else
            {
                int keyBytes = (256 / 8);
                int len = mKey.ToString().Length;
                string key = mKey;

                if ((len < keyBytes))
                {
                    int repeatFactor = keyBytes / len;
                    for (int i = 0; i <= repeatFactor; i++)
                    {
                        key = key + mKey;
                    }
                }

                return System.Text.Encoding.UTF8.GetBytes(key.Substring(0, keyBytes)); ;
            }
        }

        public virtual string Encrypt(string plainText, bool IsWithUTF8)
        {
            byte[] plainByte = ASCIIEncoding.ASCII.GetBytes(plainText);
            byte[] keyByte = GetLegalKey(IsWithUTF8);

            // Set private key
            mCryptoService.Key = keyByte;
            SetLegalIV();

            // Encryptor object
            ICryptoTransform cryptoTransform = mCryptoService.CreateEncryptor();

            if (IsWithUTF8)
                return Convert.ToBase64String(cryptoTransform.TransformFinalBlock(Encoding.UTF8.GetBytes(plainText), 0, plainText.Length));
            else
            {
                // Memory stream object
                MemoryStream ms = new MemoryStream();

                // Crpto stream object
                CryptoStream cs = new CryptoStream(ms, cryptoTransform, CryptoStreamMode.Write);

                // Write encrypted byte to memory stream
                cs.Write(plainByte, 0, plainByte.Length);
                cs.FlushFinalBlock();

                // Get the encrypted byte length
                byte[] cryptoByte = ms.ToArray();

                // Convert into base 64 to enable result to be used in Xml
                return Convert.ToBase64String(cryptoByte, 0, cryptoByte.GetLength(0));
            }
        }

        public virtual string Decrypt(string cryptoText, bool IsWithUTF8)
        {
            // Convert from base 64 string to bytes
            byte[] cryptoByte = Convert.FromBase64String(cryptoText);
            byte[] keyByte = GetLegalKey(IsWithUTF8);

            // Set private key
            mCryptoService.Key = keyByte;
            SetLegalIV();

            // Decryptor object
            ICryptoTransform cryptoTransform = mCryptoService.CreateDecryptor();
            try
            {
                // Memory stream object
                MemoryStream ms = new MemoryStream(cryptoByte, 0, cryptoByte.Length);

                // Crpto stream object
                CryptoStream cs = new CryptoStream(ms, cryptoTransform, CryptoStreamMode.Read);

                // Get the result from the Crypto stream
                StreamReader sr = new StreamReader(cs);
                return sr.ReadToEnd();
            }
            catch
            {
                return null;
            }
        }

        public string Key
        {
            get
            {
                return mKey;
            }
            set
            {
                mKey = value;
            }
        }

        public string Salt
        {
            // Salt value
            get
            {
                return mSalt;
            }
            set
            {
                mSalt = value;
            }
        }
        #endregion

        #region Destructors
        /// <summary>
        /// Default Destructors
        /// </summary>
        ~SymCryptography()
        {
            Dispose();
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose Method for dispose object
        /// </summary>
        private void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Interface for dispose class
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// virtual dispoase method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }

    #endregion  
}
