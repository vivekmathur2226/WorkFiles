﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Security.Cryptography;
using System.Net;
using System.Net.Security;
using System.Net.Http.Headers;
using System.Net.Http.Formatting;
using System.Xml;
using System.Xml.Linq;
using System.Net.Http;
using System.Web.Http;
namespace Password
{
    public partial class Password : Form
    {
        public Password()
        {
            InitializeComponent();

        }
        string strReturnData = string.Empty;

        private XElement ConvertObjectToXMLString(object classObject)
        {
            XElement xElement = null;
            try
            {
                System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(classObject.GetType());
                XmlWriterSettings settings = new XmlWriterSettings();
                settings.Encoding = new System.Text.UnicodeEncoding(false, false); // no BOM in a .NET string
                settings.Indent = true;
                settings.OmitXmlDeclaration = true;
                string temp;
                using (System.IO.StringWriter textWriter = new System.IO.StringWriter())
                {
                    using (XmlWriter xmlWriter = XmlWriter.Create(textWriter, settings))
                    {
                        serializer.Serialize(xmlWriter, classObject);
                    }
                    temp = textWriter.ToString();
                    xElement = XElement.Parse(temp);
                }
            }
            catch
            {
                // Logged Exception

            }
            return xElement;
        }

        private void btnEncrypt_Click(object sender, EventArgs e)
        {
            try
            {
                if ((txtValue.Text != string.Empty) || (txtValue.Text.Length > 0) || (txtValue.Text != ""))
                {
                    txtResult.Text = CommonClass.EncryptString(txtValue.Text);

                    label3.Text = "STATUS:- Encrypted Success";
                }
                else
                {
                    label3.Text = "STATUS:- Please insert text in value box";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                label3.Text = "ERROR occurred during ENCRYPTING";
            }
        }
        private void btnDecrypt_Click(object sender, EventArgs e)
        {
            try
            {
                if ((txtValue.Text != string.Empty) || (txtValue.Text.Length > 0) || (txtValue.Text != ""))
                {
                    txtResult.Text = CommonClass.DecryptString(txtValue.Text);
                    label3.Text = "STATUS:- Decrypted Success";
                }
                else
                {
                    label3.Text = "STATUS:- Please insert text in value box";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                label3.Text = "ERROR occurred during DECRYPTING";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Creating Request XML data
            StringBuilder strRBLRequest = new StringBuilder();
            strRBLRequest.Append("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>");
            //strRBLRequest.Append("<>");
            strRBLRequest.Append(" <RetrieveTransactionStatusRequest xmlns=\"https://onlineuat.rblbank.com/corp/XService\"");
            strRBLRequest.Append(" xmlns:hd=\"https://onlineuat.rblbank.com/corp/header\"");
            strRBLRequest.Append(" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"");
            strRBLRequest.Append(" xsi:schemaLocation=\"https://onlineuat.rblbank.com/corp/XService RetrieveTransactionStatusRequest.xsd\">");

            //strRBLRequest.Append(" <RetrieveTransactionStatusRequest xmlns=\"http://www.infosys.com/request/RetrieveTransactionStatus\"");
            //strRBLRequest.Append(" xmlns:hd=\"http://www.infosys.com/request/header\"");
            //strRBLRequest.Append(" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"");
            //strRBLRequest.Append(" xsi:schemaLocation=\"http://www.infosys.com/request/RetrieveTransactionStatus RetrieveTransactionStatusRequest.xsd\">");

            strRBLRequest.Append("<hd:header>");
            strRBLRequest.Append("<hd:BANK_ID>176</hd:BANK_ID>");
            strRBLRequest.Append("<hd:LANGUAGE_ID>001</hd:LANGUAGE_ID>");
            strRBLRequest.Append("<hd:CHANNEL_ID>I</hd:CHANNEL_ID>");
            strRBLRequest.Append("<hd:LOGIN_FLAG>2</hd:LOGIN_FLAG>");
            strRBLRequest.Append("<hd:__SRVCID__>RRTSE</hd:__SRVCID__>");
            strRBLRequest.Append("<hd:STATEMODE>N</hd:STATEMODE>");
            strRBLRequest.Append("<hd:OPFMT>XML</hd:OPFMT>");
            strRBLRequest.Append("<hd:IPFMT>XML</hd:IPFMT>");
            strRBLRequest.Append("<hd:ISMULTIREC>N</hd:ISMULTIREC>");
            strRBLRequest.Append("<hd:USER_PRINCIPAL>176.ESOPADM1</hd:USER_PRINCIPAL>");
            strRBLRequest.Append("<hd:CORP_PRINCIPAL></hd:CORP_PRINCIPAL>");
            strRBLRequest.Append("<hd:ACCESS_CODE>d#demo1234</hd:ACCESS_CODE>");
            strRBLRequest.Append("<hd:FORM_ID></hd:FORM_ID>");
            strRBLRequest.Append("<hd:LOGIN_TYPE></hd:LOGIN_TYPE>");
            strRBLRequest.Append("<hd:RELATIONSHIP_ID></hd:RELATIONSHIP_ID>");
            strRBLRequest.Append("<hd:IP_ADDRESS></hd:IP_ADDRESS>");
            strRBLRequest.Append("<hd:PORTAL_REQUEST></hd:PORTAL_REQUEST>");
            strRBLRequest.Append("<hd:PORTAL_RANDOM_ID></hd:PORTAL_RANDOM_ID>");
            strRBLRequest.Append("<hd:USER_ID></hd:USER_ID>");
            strRBLRequest.Append("<hd:ISATTACHMENT></hd:ISATTACHMENT>");
            strRBLRequest.Append("<hd:DEVICE_ID></hd:DEVICE_ID>");
            strRBLRequest.Append("<hd:DEVICE_TYPE></hd:DEVICE_TYPE>");
            strRBLRequest.Append("<hd:MACHINE_FINGER_PRINT></hd:MACHINE_FINGER_PRINT>");
            strRBLRequest.Append("<hd:BROWSER_TYPE></hd:BROWSER_TYPE>");
            strRBLRequest.Append("<hd:REQUESTED_FRAME_START_INDEX></hd:REQUESTED_FRAME_START_INDEX>");
            strRBLRequest.Append("</hd:header>");

            strRBLRequest.Append("<RetrieveTransactionStatus>");
            strRBLRequest.Append("<BNF_ID>281207</BNF_ID>");
            strRBLRequest.Append("<REFERENCE_ID>1939249</REFERENCE_ID>");
            strRBLRequest.Append("<TOTAL_AMOUNT>2</TOTAL_AMOUNT>");
            //Reference Id passed and transaction date needs to valid to get the response as observed via SAOP UI
            strRBLRequest.Append("<TRANSACTION_DATE>05/06/2017</TRANSACTION_DATE>"); //DateTime.Now.ToString("dd/MM/yyyy").ToUpper()
            strRBLRequest.Append("<TRANSACTION_CURRENCY>INR</TRANSACTION_CURRENCY>");
            strRBLRequest.Append("<DESTINATION_ENTITY_TYPE>M</DESTINATION_ENTITY_TYPE>");
            strRBLRequest.Append("<CP_REMARKS></CP_REMARKS>");
            strRBLRequest.Append("</RetrieveTransactionStatus>");
            strRBLRequest.Append("</RetrieveTransactionStatusRequest>");


            string str_PaymentDetails = "";
            str_PaymentDetails = "Action: PG Dual Verification Initiated |";
            str_PaymentDetails = str_PaymentDetails + strRBLRequest.ToString();

            string strReturnData = string.Empty;
            string xData = string.Empty;
            string postData = string.Empty;
                        
            //var strEncryptedValue = new StringContent(ConvertObjectToXMLString(strRBLRequest.ToString()).ToString());
            //Commented the method call
            Task<string> strRetData = HttpClientCall(new StringContent(strRBLRequest.ToString(), Encoding.UTF8, "application/xml"));
            MessageBox.Show(strRetData.Result.ToString());
            
            //Create a HttpClient
            //using (System.Net.Http.HttpClient client = new System.Net.Http.HttpClient())
            //{
            //    //Create a webrequest
            //    //WebRequest request = WebRequest.Create("https://onlineuat.rblbank.com/corp/XService");
            //    HttpRequestMessage requestMessage = new HttpRequestMessage(HttpMethod.Post, "https://onlineuat.rblbank.com/corp/XService");
            //    requestMessage.Headers.Clear();
            //    requestMessage.Headers.TryAddWithoutValidation("Content-Type", "application/xml");
            //    requestMessage.Headers.TryAddWithoutValidation("IPTYPE", "XML");
            //    requestMessage.Content = new StringContent(strRBLRequest.ToString(), Encoding.UTF8, "application/xml");
            //    requestMessage.Content.Headers.TryAddWithoutValidation("IPTYPE", "XML");
            //    //    requestMessage.Method = "Post";
            //    //    postData = "XMLData=" + xd;
            //    //    byte[] byteArray = Encoding.UTF8.GetBytes(xd.InnerXml.ToString());                
            //    //    var httpContent = new StringContent(xd.InnerXml.ToString(), Encoding.UTF8, "application/xml");
            //    //     // Send the request to the server
            //    HttpResponseMessage response = client.PostAsync("https://onlineuat.rblbank.com/corp/XService", requestMessage.Content).Result;
            //    //HttpResponseMessage response = await httpClient.PostAsync(requestMessage.RequestUri, requestMessage.Content).ConfigureAwait(false);
            //    strReturnData =  response.Content.ReadAsStringAsync().ConfigureAwait(false).ToString();
            //    response.EnsureSuccessStatusCode();
            //    MessageBox.Show(strReturnData);
            //}        
           
        }

        private async Task<string> HttpClientCall(HttpContent strContent)
        {
            // Create a client
            HttpClient httpClient = new HttpClient();
            // Add a new Request Message
            HttpRequestMessage requestMessage = new HttpRequestMessage(HttpMethod.Post, "https://onlineuat.rblbank.com/corp/XService");
            // Add our custom headers
            //requestMessage.Headers.Clear();
            requestMessage.Headers.TryAddWithoutValidation("Content-Type", "application/xml");
            requestMessage.Headers.TryAddWithoutValidation("IPTYPE", "XML");
            //requestMessage.Headers.Add("Content-Type", "application/xml");
            //requestMessage.Headers.Add("IPTYPE", "XML");
            requestMessage.Content= strContent;
            //requestMessage.Content.Headers.TryAddWithoutValidation("IPTYPE", "XML");
           
            //bytes = System.Text.Encoding.ASCII.GetBytes(xd.InnerXml);
            //requestMessage.Content = new ByteArrayContent(bytes);
           
            // Send the request to the server
            //HttpResponseMessage response = await httpClient.SendAsync(requestMessage,HttpCompletionOption.ResponseHeadersRead);
            HttpResponseMessage response = await httpClient.PostAsync(requestMessage.RequestUri, requestMessage.Content).ConfigureAwait(false);
           //strReturnData = await response.Content.ReadAsStringAsync();
            //response.EnsureSuccessStatusCode();
            return await response.Content.ReadAsStringAsync();           
        }
    }
}
