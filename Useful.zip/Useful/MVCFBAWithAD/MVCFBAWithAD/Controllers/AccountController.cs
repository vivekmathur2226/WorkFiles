﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using MVCFBAWithAD.Models;
using System.Security;
using System.Configuration;
using Galactic.ActiveDirectory;
using System.DirectoryServices.Protocols;
using System.Security.Principal;

namespace MVCFBAWithAD.Controllers
{
    [Authorize]
    public class AccountController : Controller
    {
        //
        // GET: /Account/Login

        [AllowAnonymous]
        public ActionResult Login(string returnUrl)
        {
            ViewBag.ReturnUrl = returnUrl;
            return View();
        }

        //
        // POST: /Account/Login

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public ActionResult Login(LoginModel model, string returnUrl)
        {
            string serverName = ConfigurationManager.AppSettings["ADServer"];
            if (ModelState.IsValid)
            {
                SecureString securePwd = null;
                if (model.Password != null)
                {
                    securePwd = new SecureString();
                    foreach (char chr in model.Password.ToCharArray())
                    {
                        securePwd.AppendChar(chr);
                    }
                }
                try
                {
                    //Check user credentials
                    ActiveDirectory adVerifyUser = new ActiveDirectory(serverName, model.UserName, securePwd);

                    FormsAuthentication.SetAuthCookie(model.UserName, model.RememberMe);
                    return RedirectToLocal(returnUrl);
                }
                catch
                {
                    // If we got this far, something failed, redisplay form
                    ModelState.AddModelError("", "The user name or password provided is incorrect.");
                }
            }

            return View(model);
        }

        //
        // POST: /Account/LogOff

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LogOff()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Home");
        }

        public ActionResult UserProfile()
        {
            string serverName = ConfigurationManager.AppSettings["ADServer"];
            string userName = ConfigurationManager.AppSettings["ADUserName"];
            string password = ConfigurationManager.AppSettings["ADPassword"];
            SecureString securePwd = null;
            if (password != null)
            {
                securePwd = new SecureString();
                foreach (char chr in password.ToCharArray())
                {
                    securePwd.AppendChar(chr);
                }
            }
            UserProfile usrProfile = new UserProfile();
            try
            {
                ActiveDirectory adConnect = new ActiveDirectory(serverName, userName, securePwd);
                List<SearchResultEntry> results = adConnect.GetEntriesBySAMAccountName(User.Identity.Name);
                if (results.Count > 0)
                {
                    User usr = new User(adConnect, results[0]);
                    usrProfile.FirstName = usr.FirstName;
                    usrProfile.LastName = usr.LastName;
                    usrProfile.Manager = usr.Manager;
                    usrProfile.Department = usr.Department;
                    usrProfile.Division = usr.Division;
                    usrProfile.EmployeeId = usr.EmployeeId;
                    usrProfile.EmployeeNumber = usr.EmployeeNumber;
                    usrProfile.PhoneNumber = usr.PhoneNumber;
                    usrProfile.StreetAddress = usr.StreetAddress;
                    usrProfile.Title = usr.Title;
                    usrProfile.UserName = usr.DisplayName;
                    usrProfile.Groups = usr.Groups;                  
                }
            }
            catch
            {
                // unable to connect AD
                ModelState.AddModelError("", "Unable to connect AD!");
            }
            return View(usrProfile);
        }

        #region Helpers
        private ActionResult RedirectToLocal(string returnUrl)
        {
            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }
        private bool CheckUserInGroup(string group)
        {
            string serverName = ConfigurationManager.AppSettings["ADServer"];
            string userName = ConfigurationManager.AppSettings["ADUserName"];
            string password = ConfigurationManager.AppSettings["ADPassword"];
            bool result = false;
            SecureString securePwd = null;
            if (password != null)
            {
                securePwd = new SecureString();
                foreach (char chr in password.ToCharArray())
                {
                    securePwd.AppendChar(chr);
                }
            }
            try
            {   
                ActiveDirectory adConnectGroup = new ActiveDirectory(serverName, userName, securePwd);
                SearchResultEntry groupResult = adConnectGroup.GetEntryByCommonName(group);
                Group grp = new Group(adConnectGroup, groupResult);
                SecurityPrincipal userPrincipal = grp.Members.Find(sp => sp.SAMAccountName.ToLower() == User.Identity.Name.ToLower());
                if (userPrincipal != null)
                {
                    result = true;
                }
            }
            catch
            {
                result = false;
            }
            return result;
        }
        #endregion
    }
}
