﻿Imports System.IO
Imports System.Security.Cryptography
Imports System.Text

Namespace Password

#Region "CRYPTOGRAPHY BY AES ALGORITHM"
    Public Class VBCryptography
        Private symCipherAlgo As String = "AES"
        Private keyLength As Integer = 256
        Public strAESkey1 As String = "29304E8758327892"

        Public Sub New()
        End Sub

        'Added the VB code logic shared by RBL

        Public Shared Function RBLEncryptString(strQueryString As String) As String
            Try
                Dim randomByt As Byte() = getKey("29304E8758327892", "AES")
                Dim UTF8 As New System.Text.UTF8Encoding()
                Dim tdes As New AesManaged()
                tdes.Key = randomByt
                'UTF8.GetBytes(randomByt)
                tdes.Mode = CipherMode.ECB
                tdes.Padding = PaddingMode.PKCS7
                Dim encryptor As ICryptoTransform = tdes.CreateEncryptor()
                Dim CipherText As Byte() = Nothing
                CipherText = encryptor.TransformFinalBlock(Encoding.UTF8.GetBytes(strQueryString), 0, strQueryString.Length)

                'Cipher.Clear()
                'Transform.Dispose()
                Return Convert.ToBase64String(CipherText)
            Catch ex As Exception
                Throw New System.Exception(ex.ToString())
            End Try
        End Function

        Public Shared Function RBLDecodeString(cipherText As String) As String
            Dim randomByt As Byte() = getKey("29304E8758327892", "AES")
            Dim UTF8 As New System.Text.UTF8Encoding()
            Dim tdes As New AesManaged()
            tdes.Key = randomByt
            'UTF8.GetBytes(randomByt)
            tdes.Mode = CipherMode.ECB
            tdes.Padding = PaddingMode.PKCS7
            Dim crypt As ICryptoTransform = tdes.CreateDecryptor()

            Dim encryptedBytes As Byte() = Convert.FromBase64CharArray(cipherText.ToCharArray(), 0, cipherText.Length)
            Dim decryptedData As Byte() = crypt.TransformFinalBlock(encryptedBytes, 0, encryptedBytes.Length)
            Return ASCIIEncoding.UTF8.GetString(decryptedData)

        End Function

        Public Shared Function getKey(randomId As String, cipherName As String) As Byte()
            Dim functionReturnValue As Byte() = Nothing
            functionReturnValue = Nothing
            Try
                Dim keyBytes As Integer = (256 \ 8)
                Dim len As Integer = randomId.Length
                Dim key As String = randomId

                If (len < keyBytes) Then
                    Dim repeatFactor As Integer = keyBytes \ len
                    For i As Integer = 0 To repeatFactor
                        key = key & randomId
                    Next
                End If

                Return System.Text.Encoding.UTF8.GetBytes(key.Substring(0, keyBytes))
                'objlog.LogMessage("ValidateUser", "getKey", ex.Message.ToString, LogType.EXCEPTION, "Admin")
            Catch ex As Exception
            End Try
            Return functionReturnValue
        End Function

        Protected Overrides Sub Finalize()

            Try
            Finally
                MyBase.Finalize()
            End Try
        End Sub
    End Class
#End Region

End Namespace

