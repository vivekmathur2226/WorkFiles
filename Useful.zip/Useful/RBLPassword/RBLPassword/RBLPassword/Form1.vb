﻿Imports System.Data
Imports System.Drawing
Imports System.Linq
Imports System.Text
Imports System.Threading.Tasks
Imports System.Windows.Forms
Imports System.IO
Imports System.Security.Cryptography
Public Class Form1

    Private Sub btnEncrypt_Click(sender As Object, e As EventArgs) Handles btnEncrypt.Click
        Try
            If (txtValue.Text <> String.Empty) OrElse (txtValue.Text.Length > 0) OrElse (txtValue.Text <> "") Then
                txtResult.Text = RBLPassword.VBPassword.CommonVBClass.EncryptString(txtValue.Text)
                label3.Text = "STATUS:- Encrypted Success"
            Else
                label3.Text = "STATUS:- Please insert text in value box"
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
            label3.Text = "ERROR occurred during EnCRYPTING"
        End Try
    End Sub

    Private Sub btnDecrypt_Click(sender As Object, e As EventArgs)
        
    End Sub

    Private Sub btnDecrypt_Click_1(sender As Object, e As EventArgs) Handles btnDecrypt.Click
        Try
            If (txtValue.Text <> String.Empty) OrElse (txtValue.Text.Length > 0) OrElse (txtValue.Text <> "") Then
                txtResult.Text = RBLPassword.VBPassword.CommonVBClass.DecryptString(txtValue.Text)
                label3.Text = "STATUS:- Decrypted Success"
            Else
                label3.Text = "STATUS:- Please insert text in value box"
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
            label3.Text = "ERROR occurred during DECRYPTING"
        End Try
    End Sub
End Class
