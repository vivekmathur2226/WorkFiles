﻿Imports System.IO
Imports System.Security.Cryptography
Imports System.Text
Namespace VBPassword
    Class CommonVBClass
        'this method is passing parameter to cryptography class to encrypt data 
        Public Shared Function EncryptString(strQueryString As String) As String
            Try
                Return Password.VBCryptography.RBLEncryptString(strQueryString)
            Catch ex As Exception
                Throw New System.Exception(ex.ToString())
            End Try
        End Function
        'this method is passing parameter to cryptography class to decrypt data 
        Public Shared Function DecryptString(strQueryString As String) As String
            Try
                Return Password.VBCryptography.RBLDecodeString(strQueryString)
            Catch ex As Exception
                Throw New System.Exception(ex.ToString())
            End Try
        End Function


    End Class
End Namespace
