﻿Imports ESOP.Utility
Imports System.IO
Imports System.Security.Cryptography
Imports System.Text
Public Class RBLPassword

    Private Sub btnEncrypt_Click(sender As Object, e As EventArgs) Handles btnEncrypt.Click
        Try
            If (txtValue.Text <> String.Empty) OrElse (txtValue.Text.Length > 0) OrElse (txtValue.Text <> "") Then
                txtResult.Text = VBPassword.CommonVBClass.EncryptString(txtValue.Text)
                label3.Text = "STATUS:- Encrypted Success"
            Else
                label3.Text = "STATUS:- Please insert text in value box"
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
            label3.Text = "ERROR occurred during ENCRYPTING"
        End Try
    End Sub

    Private Sub btnDecrypt_Click(sender As Object, e As EventArgs)
        Try
            If (txtValue.Text <> String.Empty) OrElse (txtValue.Text.Length > 0) OrElse (txtValue.Text <> "") Then
                txtResult.Text = VBPassword.CommonVBClass.DecryptString(txtValue.Text)
                label3.Text = "STATUS:- Decrypted Success"
            Else
                label3.Text = "STATUS:- Please insert text in value box"
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
            label3.Text = "ERROR occurred during DECRYPTING"
        End Try
    End Sub

End Class