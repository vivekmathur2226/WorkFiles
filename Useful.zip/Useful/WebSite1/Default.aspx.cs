﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {   
        var st = Server.UrlEncode("AZjAAEqTKfmJVz9fJLkoQ+MKilHQ4dKBOKCMbXeACJMBmMAASpMp+YlXP18kuShD4KytO/n/6bCWDMIp8q/0+ofjcblXR4wL6e7ZAA4I2vtyKGIHKeONznbrsjwvRwoPQH5wh8ni9R81Zkf++17y+JC7AxvHsguEW0Lihx/YtMDaQlzD0+wI+YPQW68sMGKFc89sHGo/OWRauO3KW7ut+Q==");
        Response.Write(st);
    }
}