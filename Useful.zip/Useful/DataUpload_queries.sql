SELECT * FROM usr_Authentication
SELECT * FROM tra_TransactionDetails
SELECT * FROM du_MappingExcelSheetDetails
SELECT * FROM du_MappingFields
SELECT * FROM du_MappingTables
DELETE FROM du_MappingTables WHERE MappingTableID = 3


ALTER TABLE du_MappingTables ADD IsActive INT
ALTER TABLE du_MappingTables ADD Sequence INT
INSERT [dbo].[du_MappingTables] ([ExcelSheetDetailsID], [ActualTableName], [DisplayName], [FilePath], [FileName], [ExcelSheetName], [UploadMode], [Query], [ConnectionString], [IsSFTPEnable], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [IsActive], [Sequence], [Is_UploadDematFromFile]) VALUES (1, N'usr_UserInfo', N'Insider Employee', NULL, N'File.txt', NULL, N'QueryBased', N'SELECT EMPLOYEE_NUMBER , FIRST_NAME, MIDDLE_NAMES, LAST_NAME, CITY, PINCODE, MOBILE_NO, OFFICIAL_EMAIL_ID, PAN_NUMBER, ROLE_NAME, DATE_OF_JOINING, GRADE_NAME, DEPARTMENT, 
LWD AS DateOfSeparation, RESG_REASON AS ReasonForSeparation, '''' AS NoOfDaysToBeActive 
FROM  [HRMSDLDB]..[VIGIL].[AXIS_DATA_FOR_INSIDER_TRADING]', N'data source=10.9.114.86,2433;initial catalog=Vigilante_AxisBank;persist security info=True;user id=vigil;Password=axis@1234;MultipleActiveResultSets=True;Provider=SQLOLEDB;', 0, 1, CAST(0x0000A63400F3A2BD AS DateTime), 1, CAST(0x0000A63400F3A2BD AS DateTime), 0, 1, 0)
INSERT [dbo].[du_MappingTables] ([ExcelSheetDetailsID], [ActualTableName], [DisplayName], [FilePath], [FileName], [ExcelSheetName], [UploadMode], [Query], [ConnectionString], [IsSFTPEnable], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [IsActive], [Sequence], [Is_UploadDematFromFile]) VALUES (13, N'trs_TransectionDetails', N'AXISDIRECTFEED', NULL, NULL, NULL, N'QueryBased', N'SELECT ENTITY_ID,EMP_NO,TRD_NO,ENT_FULL_NAME,ENTITY_DP_AC_NO,TRD_DT,SMST_ISIN_CODE,SMST_SECURITY_NAME,TRD_SEM_ID,TRD_BUY_SELL_FLG,TRD_QTY,TRD_PRICE,ENTITY_PAN FROM Insider_Trading_Mis', N'data source=ESPS-0004;initial catalog=Vigilante_Akhilesh;persist security info=True;user id=sa;Password=Password;MultipleActiveResultSets=True;Provider=SQLOLEDB;', 0, 1, CAST(0x0000A5C000CCE25F AS DateTime), 1, CAST(0x0000A5C000CCE25F AS DateTime), 1, 2, 0)
INSERT [dbo].[du_MappingTables] ([ExcelSheetDetailsID], [ActualTableName], [DisplayName], [FilePath], [FileName], [ExcelSheetName], [UploadMode], [Query], [ConnectionString], [IsSFTPEnable], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [IsActive], [Sequence], [Is_UploadDematFromFile]) VALUES (13, N'trs_TransectionDetails', N'ESOPDIRECTFEED', N'D:\SFTPFiles\', N'ESOP_Vigilante_AllotData.xls', N'ESOP_Vigilante_AllotData', N'FileBased', N'', N'', 1, 1, CAST(0x0000A5C000CCE25F AS DateTime), 1, CAST(0x0000A5C000CCE25F AS DateTime), 0, 3, 1)
INSERT [dbo].[du_MappingTables] ([ExcelSheetDetailsID], [ActualTableName], [DisplayName], [FilePath], [FileName], [ExcelSheetName], [UploadMode], [Query], [ConnectionString], [IsSFTPEnable], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [IsActive], [Sequence], [Is_UploadDematFromFile]) VALUES (14, N'trs_TransectionDetails', N'KARVYFILE', N'D:\SFTPFiles\', N'KA_Vigilante_RNTData.CSV', N'KA_Vigilante_RNTData', N'FileBased', N'', N'', 0, 1, CAST(0x0000A5C000CCE25F AS DateTime), 1, CAST(0x0000A5C000CCE25F AS DateTime), 0, 4, 0)

--DELETE FROM du_MappingFields WHERE MappingFieldID > 101
INSERT [dbo].[du_MappingFields] ([MappingTableID], [ActualFieldName], [ActualFieldIsRequired], [ActualFieldDataType], [DisplayFieldName], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES (2, N'TransactionMasterId', 1, N'INT', N'Sr No', 1, CAST(0x0000A5C000D0D184 AS DateTime), 1, CAST(0x0000A5C000D0D184 AS DateTime))
INSERT [dbo].[du_MappingFields] ([MappingTableID], [ActualFieldName], [ActualFieldIsRequired], [ActualFieldDataType], [DisplayFieldName], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES (2, N'UserLoginName', 1, N'string', N'LoginID', 1, CAST(0x0000A5C000D1EA82 AS DateTime), 1, CAST(0x0000A5C000D1EA82 AS DateTime))
INSERT [dbo].[du_MappingFields] ([MappingTableID], [ActualFieldName], [ActualFieldIsRequired], [ActualFieldDataType], [DisplayFieldName], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES (2, N'RelationCodeId', 1, N'INT', N'Relation', 1, CAST(0x0000A5C000D275A8 AS DateTime), 1, CAST(0x0000A5C000D275A8 AS DateTime))
INSERT [dbo].[du_MappingFields] ([MappingTableID], [ActualFieldName], [ActualFieldIsRequired], [ActualFieldDataType], [DisplayFieldName], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES (2, N'FirstLastName', 1, N'string', N'FirstNameLastName', 1, CAST(0x0000A5C000D2DA0B AS DateTime), 1, CAST(0x0000A5C000D2DA0B AS DateTime))
INSERT [dbo].[du_MappingFields] ([MappingTableID], [ActualFieldName], [ActualFieldIsRequired], [ActualFieldDataType], [DisplayFieldName], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES (2, N'DateOfAcquisition', 1, N'DATETIME', N'TRD_DT', 1, CAST(0x0000A5C000D3280F AS DateTime), 1, CAST(0x0000A5C000D3280F AS DateTime))
INSERT [dbo].[du_MappingFields] ([MappingTableID], [ActualFieldName], [ActualFieldIsRequired], [ActualFieldDataType], [DisplayFieldName], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES (2, N'ModeOfAcquisitionCodeId', 1, N'INT', N'ModeOfAcquisitionCodeId', 1, CAST(0x0000A5C000D35BC2 AS DateTime), 1, CAST(0x0000A5C000D35BC2 AS DateTime))
INSERT [dbo].[du_MappingFields] ([MappingTableID], [ActualFieldName], [ActualFieldIsRequired], [ActualFieldDataType], [DisplayFieldName], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES (2, N'DateOfInitimationToCompany', 1, N'DATETIME', N'DateOfInitimationToCompany', 1, CAST(0x0000A5C000D3803C AS DateTime), 1, CAST(0x0000A5C000D3803C AS DateTime))
INSERT [dbo].[du_MappingFields] ([MappingTableID], [ActualFieldName], [ActualFieldIsRequired], [ActualFieldDataType], [DisplayFieldName], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES (2, N'SecuritiesHeldPriorToAcquisition', 0, N'decimal', N'SecuritiesHeldPriorToAcquisition', 1, CAST(0x0000A5C000D3A679 AS DateTime), 1, CAST(0x0000A5C000D3A679 AS DateTime))
INSERT [dbo].[du_MappingFields] ([MappingTableID], [ActualFieldName], [ActualFieldIsRequired], [ActualFieldDataType], [DisplayFieldName], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES (2, N'DEMATAccountNo', 1, N'string', N'DEMATAccountNo', 1, CAST(0x0000A5C000D3CEFA AS DateTime), 1, CAST(0x0000A5C000D3CEFA AS DateTime))
INSERT [dbo].[du_MappingFields] ([MappingTableID], [ActualFieldName], [ActualFieldIsRequired], [ActualFieldDataType], [DisplayFieldName], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES (2, N'ExchangeCodeId', 1, N'INT', N'ExchangeCodeId', 1, CAST(0x0000A5C000D3FF0B AS DateTime), 1, CAST(0x0000A5C000D3FF0B AS DateTime))
INSERT [dbo].[du_MappingFields] ([MappingTableID], [ActualFieldName], [ActualFieldIsRequired], [ActualFieldDataType], [DisplayFieldName], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES (2, N'TransactionTypeCodeId', 1, N'INT', N'TRD_BUY_SELL_FLG', 1, CAST(0x0000A5C000D44F03 AS DateTime), 1, CAST(0x0000A5C000D44F03 AS DateTime))
INSERT [dbo].[du_MappingFields] ([MappingTableID], [ActualFieldName], [ActualFieldIsRequired], [ActualFieldDataType], [DisplayFieldName], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES (2, N'SecurityTypeCodeId', 1, N'INT', N'SecurityTypeCodeId', 1, CAST(0x0000A5C000D47522 AS DateTime), 1, CAST(0x0000A5C000D47522 AS DateTime))
INSERT [dbo].[du_MappingFields] ([MappingTableID], [ActualFieldName], [ActualFieldIsRequired], [ActualFieldDataType], [DisplayFieldName], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES (2, N'PerOfSharesPreTransaction', 0, N'decimal', N'PerOfSharesPreTransaction', 1, CAST(0x0000A5C000D495FF AS DateTime), 1, CAST(0x0000A5C000D495FF AS DateTime))
INSERT [dbo].[du_MappingFields] ([MappingTableID], [ActualFieldName], [ActualFieldIsRequired], [ActualFieldDataType], [DisplayFieldName], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES (2, N'PerOfSharesPostTransaction', 0, N'decimal', N'PerOfSharesPostTransaction', 1, CAST(0x0000A5C000D4C304 AS DateTime), 1, CAST(0x0000A5C000D4C304 AS DateTime))
INSERT [dbo].[du_MappingFields] ([MappingTableID], [ActualFieldName], [ActualFieldIsRequired], [ActualFieldDataType], [DisplayFieldName], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES (2, N'Quantity', 1, N'decimal', N'TRD_QTY', 1, CAST(0x0000A5C000D5C981 AS DateTime), 1, CAST(0x0000A5C000D5C981 AS DateTime))
INSERT [dbo].[du_MappingFields] ([MappingTableID], [ActualFieldName], [ActualFieldIsRequired], [ActualFieldDataType], [DisplayFieldName], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES (2, N'Value', 1, N'decimal', N'Value', 1, CAST(0x0000A5C000D5F15B AS DateTime), 1, CAST(0x0000A5C000D5F15B AS DateTime))
INSERT [dbo].[du_MappingFields] ([MappingTableID], [ActualFieldName], [ActualFieldIsRequired], [ActualFieldDataType], [DisplayFieldName], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES (2, N'ESOPQuantity', 0, N'decimal', N'ESOPQuantity', 1, CAST(0x0000A5C000D666C5 AS DateTime), 1, CAST(0x0000A5C000D666C5 AS DateTime))
INSERT [dbo].[du_MappingFields] ([MappingTableID], [ActualFieldName], [ActualFieldIsRequired], [ActualFieldDataType], [DisplayFieldName], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES (2, N'OtherQuantity', 0, N'decimal', N'TRD_QTY', 1, CAST(0x0000A5C000D68345 AS DateTime), 1, CAST(0x0000A5C000D68345 AS DateTime))
INSERT [dbo].[du_MappingFields] ([MappingTableID], [ActualFieldName], [ActualFieldIsRequired], [ActualFieldDataType], [DisplayFieldName], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES (2, N'Quantity2', 0, N'decimal', N'Quantity2', 1, CAST(0x0000A5C000D6A981 AS DateTime), 1, CAST(0x0000A5C000D6A981 AS DateTime))
INSERT [dbo].[du_MappingFields] ([MappingTableID], [ActualFieldName], [ActualFieldIsRequired], [ActualFieldDataType], [DisplayFieldName], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES (2, N'Value2', 0, N'decimal', N'Value2', 1, CAST(0x0000A5C000D6CB9D AS DateTime), 1, CAST(0x0000A5C000D6CB9D AS DateTime))
INSERT [dbo].[du_MappingFields] ([MappingTableID], [ActualFieldName], [ActualFieldIsRequired], [ActualFieldDataType], [DisplayFieldName], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES (2, N'LotSize', 0, N'INT', N'LotSize', 1, CAST(0x0000A5C000D71698 AS DateTime), 1, CAST(0x0000A5C000D71698 AS DateTime))
INSERT [dbo].[du_MappingFields] ([MappingTableID], [ActualFieldName], [ActualFieldIsRequired], [ActualFieldDataType], [DisplayFieldName], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES (2, N'ContractSpecification', 0, N'string', N'ContractSpecification', 1, CAST(0x0000A5C000D76004 AS DateTime), 1, CAST(0x0000A5C000D76004 AS DateTime))


USE [Vigilante_anand3_Global]
GO
SELECT * FROM du_type_OnGoingContDiscData
/****** Object:  UserDefinedTableType [dbo].[du_type_OnGoingContDiscData]    Script Date: 01/25/2018 11:09:55 ******/
IF  EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'du_type_OnGoingContDiscData' AND ss.name = N'dbo')
DROP TYPE [dbo].[du_type_OnGoingContDiscData]
GO

USE [Vigilante_anand3_Global]
GO

/****** Object:  UserDefinedTableType [dbo].[du_type_OnGoingContDiscData]    Script Date: 01/25/2018 11:09:08 ******/
CREATE TYPE [dbo].[du_type_OnGoingContDiscData] AS TABLE(
	[ENTITY_ID] [varchar](500) NULL,
	[EMP_NO] [varchar](500) NULL,
	[TRD_NO] [varchar](500) NULL,
	[ENT_FULL_NAME] [varchar](500) NULL,
	[ENTITY_DP_AC_NO] [varchar](500) NULL,
	[TRD_DT] [datetime] NULL,
	[SMST_ISIN_CODE] [varchar](500) NULL,
	[SMST_SECURITY_NAME] [varchar](500) NULL,
	[TRD_SEM_ID] [varchar](500) NULL,
	[TRD_BUY_SELL_FLG] [varchar](500) NULL,
	[TRD_QTY] [decimal](18, 2) NULL,
	[TRD_PRICE] [decimal](18, 2) NULL,
	[ENTITY_PAN] [varchar](20) NULL
)
GO

USE [Vigilante_anand3_Global]
GO
/****** Object:  StoredProcedure [dbo].[st_du_OnGoingContDiscData]    Script Date: 01/25/2018 11:12:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
DROP PROCEDURE [dbo].[st_du_OnGoingContDiscData]
CREATE PROCEDURE [dbo].[st_du_OnGoingContDiscData]
	@OnGoingContDiscData du_type_OnGoingContDiscData READONLY
AS	
BEGIN
	SET NOCOUNT ON;
		
		DECLARE @PAID_UP_SHARES DECIMAL
		SET @PAID_UP_SHARES = (SELECT TOP 1 PaidUpShare FROM com_CompanyPaidUpAndSubscribedShareCapital ORDER BY CompanyPaidUpAndSubscribedShareCapitalID DESC)
		
		/* Created temp data to get SecurityHeldPriorToAcquisition */
		CREATE TABLE #TEMP_DATA
		(
			EmployeeId VARCHAR(200) , DisclosureTypeCodeId VARCHAR(50), Quantity  VARCHAR(50), PAN VARCHAR(15)		
		)
		
		INSERT INTO #TEMP_DATA (EmployeeId, DisclosureTypeCodeId, Quantity, PAN)
		
		SELECT  UF.EmployeeId, TRM.DisclosureTypeCodeId, CASE WHEN (DisclosureTypeCodeId = '147001') THEN AVG(TRD.Quantity) ELSE MAX(TRD.SecuritiesPriorToAcquisition + TRD.Quantity) END AS Quantity, PAN FROM tra_TransactionMaster AS TRM
					INNER JOIN tra_TransactionDetails TRD ON TRD.TransactionMasterId = TRM.TransactionMasterId 
					INNER JOIN usr_UserInfo UF ON UF.UserInfoId = TRM.UserInfoId
					WHERE (TRM.DisclosureTypeCodeId IN (147001, 147002))  AND (TRD.SecurityTypeCodeId = 139001)
					GROUP BY UF.EmployeeId, TRM.DisclosureTypeCodeId, TRD.SecurityTypeCodeId, UF.PAN 
					ORDER BY DisclosureTypeCodeId DESC
		
		
		ALTER TABLE #TEMP_DATA ADD ROWID INT IDENTITY(1,1)
		
		DECLARE @MIN INT, @MAX INT
		
		SELECT @MIN = MIN(ROWID), @MAX = MAX(ROWID) FROM #TEMP_DATA
		
		/* Inserted temp data to get %Share PreTransaction and %Share Post Transaction */
		PRINT @MIN
		PRINT @MAX
		WHILE(@MIN <= @MAX)
		BEGIN
			IF EXISTS ( SELECT EmployeeId FROM #TEMP_DATA WHERE DisclosureTypeCodeId = 147002 AND ROWID = @MIN)
			BEGIN
				DELETE FROM #TEMP_DATA WHERE PAN = (SELECT PAN FROM #TEMP_DATA WHERE DisclosureTypeCodeId = 147002 AND ROWID = @MIN) and DisclosureTypeCodeId = 147001
			END
			SET @MIN = @MIN + 1
		END

		--select * from #TEMP_DATA
		--drop table #TEMP_DATA
		
		/* Prapare records for upload data */
		
		SELECT * INTO #TEMP FROM
		(
			SELECT EMP_NO,TRD_DT, UserInfoId, LoginID, FirstNameLastName, ENTITY_ID, ENT_FULL_NAME, ENTITY_DP_AC_NO,  SMST_ISIN_CODE, SMST_SECURITY_NAME, TRD_SEM_ID, TRD_BUY_SELL_FLG, SUM(TRD_QTY) AS TRD_QTY, SUM(TRD_PRICE) AS TRD_PRICE, SUM(TRD_QTY * TRD_PRICE) AS Value, ModeOfAcquisition, DateOfInitimationToCompany, ExchangeCodeId, SecurityTypeCodeId, Relation, Quantity, DisclosureTypeCodeId, DEMATAccountNo
			FROM
			(
				SELECT 
					EMP_NO, TRD_DT, USI.UserInfoId, USA.LoginID, (ISNULL(USI.FirstName, '') + ISNULL(USI.LastName, '')) AS FirstNameLastName,
					ENTITY_ID, ENT_FULL_NAME, ENTITY_DP_AC_NO,  SMST_ISIN_CODE, SMST_SECURITY_NAME, TRD_SEM_ID, 
					CASE WHEN TRD_BUY_SELL_FLG = 'B' THEN 'Buy' WHEN TRD_BUY_SELL_FLG = 'S' THEN 'Sell' ELSE 'Buy' END AS TRD_BUY_SELL_FLG, 
					TRD_QTY, TRD_PRICE,
					CASE WHEN TRD_BUY_SELL_FLG = 'B' THEN 'Market Purchase' WHEN TRD_BUY_SELL_FLG = 'S' THEN 'Market Sale' ELSE '' END AS ModeOfAcquisition, GETDATE() as DateOfInitimationToCompany, 'National Stock Exchange of India Limited' AS ExchangeCodeId, 'Shares' AS SecurityTypeCodeId,
					(CASE WHEN UR.UserInfoIdRelative != NULL OR UR.UserInfoIdRelative != '' THEN COM.CodeName ELSE 'Self' END) AS Relation, TD.Quantity , TD.DisclosureTypeCodeId, 
					ENTITY_DP_AC_NO AS DEMATAccountNo
				FROM @OnGoingContDiscData AS OGCD
				LEFT OUTER JOIN #TEMP_DATA AS TD ON OGCD.ENTITY_PAN = TD.PAN
				INNER JOIN usr_UserInfo AS USI ON OGCD.ENTITY_PAN = USI.PAN
				INNER JOIN usr_Authentication AS USA ON USI.UserInfoId = USA.UserInfoID
				LEFT OUTER JOIN usr_UserRelation AS UR ON USI.UserInfoId = UR.UserInfoID
				LEFT OUTER JOIN com_Code AS COM ON UR.RelationTypeCodeId = COM.CodeID
				
			)#TEMP
			GROUP BY
			EMP_NO, TRD_DT, UserInfoId, LoginID, FirstNameLastName, ENTITY_ID, ENT_FULL_NAME, ENTITY_DP_AC_NO, SMST_ISIN_CODE, SMST_SECURITY_NAME, TRD_SEM_ID, TRD_BUY_SELL_FLG, ModeOfAcquisition, DateOfInitimationToCompany, ExchangeCodeId, SecurityTypeCodeId, Relation, Quantity, DisclosureTypeCodeId, DEMATAccountNo
			
		) AS X
		
		SELECT * INTO #T2 FROM
		(
			SELECT EMP_NO, TRD_DT, UserInfoId, LoginID, FirstNameLastName, ENTITY_ID, ENT_FULL_NAME, ENTITY_DP_AC_NO, SMST_ISIN_CODE, SMST_SECURITY_NAME, TRD_SEM_ID, TRD_BUY_SELL_FLG, ModeOfAcquisition, DateOfInitimationToCompany, ExchangeCodeId, SecurityTypeCodeId, Relation, (CASE WHEN DisclosureTypeCodeId = 147001 THEN Quantity ELSE (Quantity) END) AS SecuritiesHeldPriorToAcquisition, TRD_QTY, TRD_PRICE, Value,  DEMATAccountNo
			FROM #TEMP temp
		)AS T2
		
		SELECT EMP_NO AS [Sr No], EMP_NO, TRD_DT, TRD_QTY, TRD_PRICE, UserInfoId, LoginID, FirstNameLastName, ENTITY_ID, ENT_FULL_NAME, ENTITY_DP_AC_NO, SMST_ISIN_CODE, SMST_SECURITY_NAME, TRD_SEM_ID, TRD_BUY_SELL_FLG, ModeOfAcquisition AS ModeOfAcquisitionCodeId, DateOfInitimationToCompany, ExchangeCodeId, SecurityTypeCodeId, Relation, SecuritiesHeldPriorToAcquisition,
			   ((SecuritiesHeldPriorToAcquisition/@PAID_UP_SHARES)*100) AS PerOfSharesPreTransaction, (((SecuritiesHeldPriorToAcquisition - TRD_QTY)/@PAID_UP_SHARES)*100) AS PerOfSharesPostTransaction, DEMATAccountNo, Value, '0' AS LotSize
		FROM #T2
		
		DROP TABLE #TEMP_DATA
		
		UPDATE du_MappingTables SET Is_UploadDematFromFile = 1 WHERE DisplayName = 'AXISDIRECTFEED'
		
	SET NOCOUNT OFF;
END
SELECT * FROM du_MappingTables
SELECT * FROM Insider_Trading_Mis

DELETE FROM Insider_Trading_Mis
INSERT INTO dbo.Insider_Trading_Mis
	(
	ENTITY_ID,
	EMP_NO,
	TRD_NO,
	ENT_FULL_NAME,
	ENTITY_DP_AC_NO,
	TRD_DT,
	SMST_ISIN_CODE,
	SMST_SECURITY_NAME,
	TRD_SEM_ID,
	TRD_BUY_SELL_FLG,
	TRD_QTY,
	TRD_PRICE,
	ENTITY_PAN
	)
VALUES 
	(
	'104819',
	'testuser1',
	 NULL,
	'testuser1',
	'10818883',
	 dbo.uf_com_GetServerDate(),
	'INE238A01034',
	'AXIS BANK LIMITED',
	'AXISBANKEQ',
	'S',
	499,
	560,
	'FFFFF1111F'
	)

UPDATE du_MappingTables
SET ConnectionString ='data source=ESPS-0004;initial catalog=Vigilante_anand3_global;persist security info=True;user id=sa;Password=Password;MultipleActiveResultSets=True;Provider=SQLOLEDB;'
WHERE MappingTableID = 2

DECLARE @datetime DATETIME
SET @datetime = dbo.uf_com_GetServerDate()
PRINT @datetime
UPDATE Insider_Trading_Mis
SET TRD_DT = @datetime